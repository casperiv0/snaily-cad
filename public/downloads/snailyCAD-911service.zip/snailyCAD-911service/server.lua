-- CONFIG
-------------------------------------------
--- URL
local URL_TO_CAD = 'localhost' -- No slash at the end 
-------------------------------------------

-- CODE 
-------------------------------------------

-- Register chatmessage
RegisterServerEvent("chatMessage")

RegisterCommand("call911", function(source)
    CancelEvent()
    local name = GetPlayerName(source)
    TriggerClientEvent("911Call", source, name)
end)

-- register the updater
RegisterServerEvent("911CallUpdate")

-- POST the call to the CAD
AddEventHandler("911CallUpdate", function(street, name)
    PerformHttpRequest(URL_TO_CAD .. '/create-911-call',
                       function(err, text, headers) end, 'POST',
                       json.encode({name = name, location = street}),
                       {["Content-Type"] = 'application/json'})

    CancelEvent()
end)

-- CODE
-------------------------------------------