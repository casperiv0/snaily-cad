-- CONFIG
-------------------------------------------
--- URL
local URL_TO_CAD = 'http://localhost' -- No slash at the end 
local PORT = "3001"
-------------------------------------------

-- CODE 
-------------------------------------------

-- Register chatmessage
RegisterServerEvent("chatMessage")

RegisterCommand("call911", function(source)
    CancelEvent()
    local name = GetPlayerName(source)
    TriggerClientEvent("911Call", source, name)
end)

-- register the updater
RegisterServerEvent("911CallUpdate")

-- POST the call to the CAD
AddEventHandler("911CallUpdate", function(street, name)
    PerformHttpRequest(URL_TO_CAD .. ":" .. PORT .. '/call/citizen/create-911-call',
                       function(err, text, headers) end, 'POST',
                       json.encode({name = name, location = street}),
                       {["Content-Type"] = 'application/json'})

    CancelEvent()
end)

-- CODE
-------------------------------------------