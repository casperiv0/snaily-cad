-- CONFIG
-------------------------------------------
-- CAD URl
local URL_TO_CAD = 'http://localhost' -- No slash at the end 
local PORT = "3001"
-------------------------------------------



-- CODE 
-------------------------------------------

-- Register chatmessage
RegisterServerEvent("chatMessage")

RegisterCommand("calltow", function(source)
    CancelEvent()
    local name = GetPlayerName(source)
    TriggerClientEvent("towCall", source, name)
end)

-- register the updater
RegisterServerEvent("towCallUpdate")

-- POST the call to the CAD
AddEventHandler("towCallUpdate", function(street, name)
    PerformHttpRequest(URL_TO_CAD .. ":" .. PORT .. '/call/create-tow-call',
                       function(err, text, headers) end, 'POST',
                       json.encode({name = name, location = street}),
                       {["Content-Type"] = 'application/json'})

    CancelEvent()
end)

-- CODE
-------------------------------------------